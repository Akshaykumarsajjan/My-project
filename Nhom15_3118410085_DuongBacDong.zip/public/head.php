
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- favicon for webpage -->
    <link rel="shortcut icon" href="img/favicon/favicon.ico">
    <!-- <link rel="shortcut icon" type="image/png" href="img/favicon/favicon.png"> -->
    <!-- /favicon for webpage -->

    <!-- Responsive library -->
    <link rel="stylesheet" href="assets/css/gridLibrary.css">
    <!-- /Responsive library -->

    <!-- main style css -->
    <link rel="stylesheet" href="assets/css/main.css">
    <!-- /main style css -->

    <!-- base style css -->
    <link rel="stylesheet" href="assets/css/base.css">
    <!-- base style css -->

    <!-- google font trademark -->
    <link href="https://fonts.googleapis.com/css2?family=Arima+Madurai:wght@100;200;300;400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lobster+Two:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;562;600;700&display=swap" rel="stylesheet">
    <!-- /google font trademark-->

    <!-- google font default -->
    <link href="https://fonts.googleapis.com/css2?family=Manuale:wght@400;500;562;600;700&display=swap" rel="stylesheet">
    <!-- /google font default -->

    <!-- jQuery cdn -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" 
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous">
    </script>
    <!-- /jQuery cdn -->
